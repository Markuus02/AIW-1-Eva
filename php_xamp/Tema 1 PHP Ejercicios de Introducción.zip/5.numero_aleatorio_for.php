<?php
// filepath: c:\xampp\htdocs\php\numeros_1_al_10.php

/*
    ---------------------------------------------------------
    Mostrar números del 1 al 10 usando un bucle "for"
    ---------------------------------------------------------
    Este script recorre los números del 1 al 10 
    utilizando un bucle for y los imprime en pantalla
    uno por línea.
*/

// Bucle for: inicialización, condición y actualización
for ($i = 1; $i <= 10; $i++) {
    // Mostrar el valor actual de $i
    // "<br>" se usa para hacer un salto de línea en HTML
    echo $i . "<br>";
}
?>
