6️⃣ Mostrar números del 10 al 1 con `while`

<?php
// filepath: c:\xampp\htdocs\php\numero_aleatorio_while.php
$i = 10; // Inicializa la variable $i en 10. Esta variable actuará como contador.
while ($i >= 1) { // El bucle continuará ejecutándose mientras $i sea mayor o igual a 1.
    echo $i . "<br>"; // Imprime el valor actual de $i seguido de un salto de línea (<br>).
    $i--; // Decrementa el valor de $i en 1 para la siguiente iteración.
}
?>