1️⃣ Mostrar información de configuración de PHP

<?php
// Este script muestra información detallada sobre la configuración de PHP del servidor.
phpinfo(); // La función phpinfo() muestra una gran cantidad de información sobre PHP, incluyendo la versión, la configuración, los módulos cargados, etc.
?>
